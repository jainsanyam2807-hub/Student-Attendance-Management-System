package attendance.services;

import attendance.database.Database;
import attendance.models.User;
import java.util.List;

public class AuthService {
    private Database database;

    public AuthService(Database database) {
        this.database = database;
    }

    public User login(String username, String password, String role) {
        List<User> users = database.getAllUsers();
        for (User user : users) {
            if (user.getUsername().equals(username) && 
                user.getPassword().equals(password) && 
                user.getRole().equals(role)) {
                return user;
            }
        }
        return null;
    }
}
