package attendance.services;

import attendance.database.Database;
import attendance.models.AttendanceRecord;
import attendance.models.Student;
import java.util.List;
import java.util.stream.Collectors;

public class AttendanceManager {
    private Database database;

    public AttendanceManager(Database database) {
        this.database = database;
    }

    public List<Student> getStudents() {
        return database.getAllUsers().stream()
                .filter(u -> u instanceof Student)
                .map(u -> (Student) u)
                .collect(Collectors.toList());
    }

    public void markAttendance(List<AttendanceRecord> records) {
        database.saveAttendance(records);
    }

    public List<AttendanceRecord> getRecordsForStudent(String studentId) {
        return database.getAllAttendance().stream()
                .filter(r -> r.getStudentId().equals(studentId))
                .collect(Collectors.toList());
    }
    
    public List<AttendanceRecord> getRecordsForClass(String classId, String date) {
        return database.getAllAttendance().stream()
                .filter(r -> r.getClassId().equals(classId) && r.getDate().equals(date))
                .collect(Collectors.toList());
    }
}
