package attendance.services;

import attendance.database.Database;
import attendance.models.AttendanceRecord;
import java.util.List;
import java.util.stream.Collectors;

public class ReportGenerator {
    private Database database;

    public ReportGenerator(Database database) {
        this.database = database;
    }

    public double getStudentAttendancePercentage(String studentId) {
        List<AttendanceRecord> records = database.getAllAttendance().stream()
                .filter(r -> r.getStudentId().equals(studentId))
                .collect(Collectors.toList());

        if (records.isEmpty()) return 0.0;

        long presentCount = records.stream().filter(r -> r.getStatus().equalsIgnoreCase("Present")).count();
        return (double) presentCount / records.size() * 100.0;
    }

    public String generateClassReport(String classId) {
        List<AttendanceRecord> records = database.getAllAttendance().stream()
                .filter(r -> r.getClassId().equals(classId))
                .collect(Collectors.toList());

        StringBuilder report = new StringBuilder();
        report.append("--- Class Attendance Report ---\n");
        report.append("Class ID: ").append(classId).append("\n");
        report.append("Total Records: ").append(records.size()).append("\n");
        
        long presentCount = records.stream().filter(r -> r.getStatus().equalsIgnoreCase("Present")).count();
        long absentCount = records.size() - presentCount;
        
        report.append("Total Present: ").append(presentCount).append("\n");
        report.append("Total Absent: ").append(absentCount).append("\n");

        return report.toString();
    }
}
