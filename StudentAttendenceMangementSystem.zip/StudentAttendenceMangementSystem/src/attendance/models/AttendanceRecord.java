package attendance.models;

public class AttendanceRecord {
    private String date;
    private String studentId;
    private String classId;
    private String status;

    public AttendanceRecord(String date, String studentId, String classId, String status) {
        this.date = date;
        this.studentId = studentId;
        this.classId = classId;
        this.status = status;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getClassId() {
        return classId;
    }

    public void setClassId(String classId) {
        this.classId = classId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
