package attendance.models;

public class Teacher extends User {
    public Teacher(String id, String username, String password, String name) {
        super(id, username, password, "Teacher", name);
    }

    @Override
    public void displayDashboard() {
        System.out.println("Displaying Teacher Dashboard for " + getName());
    }
}
