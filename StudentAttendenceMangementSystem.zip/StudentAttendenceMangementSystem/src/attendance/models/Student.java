package attendance.models;

public class Student extends User {
    public Student(String id, String username, String password, String name) {
        super(id, username, password, "Student", name);
    }

    @Override
    public void displayDashboard() {
        System.out.println("Displaying Student Dashboard for " + getName());
    }
}
