package attendance.models;

public class Admin extends User {
    public Admin(String id, String username, String password, String name) {
        super(id, username, password, "Admin", name);
    }

    @Override
    public void displayDashboard() {
        System.out.println("Displaying Admin Dashboard for " + getName());
    }
}
